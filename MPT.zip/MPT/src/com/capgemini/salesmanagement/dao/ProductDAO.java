package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.util.DBConnection;

import exception.ProductException;

public class ProductDAO implements IProductDAO {

	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, IOException {
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		ProductBean productBean = new ProductBean();
		int queryResult = 0;
		try
		{
		
			preparedStatement = connection.prepareStatement(QueryMapper.GET_PRODUCT_QUERY);
			preparedStatement.setInt(1, productCode);
			resultSet = preparedStatement.executeQuery();
			
			
			preparedStatement1 = connection.prepareStatement(QueryMapper.UPDATE_SALES_QUERY);
			preparedStatement1.setDouble(1, resultSet.getDouble(5));
			preparedStatement1.setInt(2,productCode);
			preparedStatement1.executeUpdate();
			
			preparedStatement2 = connection.prepareStatement(QueryMapper.GET_REQUIRED_FIELDS);
			preparedStatement2.setInt(1, productCode);
			resultSet1 = preparedStatement2.executeQuery();
			/*//*-----*-------*-----*----*-----*---- //
			*      product bean object creation      *
			*//*------------------------------------*/
			while(resultSet.next())
			{
				productBean.setProductName(resultSet.getString(2));
				productBean.setProductCategory(resultSet.getString(3));
				productBean.setProductDescription(resultSet.getString(4));
				productBean.setProductPrice(resultSet.getDouble(5));
				
			}
			while(resultSet1.next())
			{
				productBean.setQuantity(resultSet1.getDouble(1));
				productBean.setLineTotal(resultSet1.getDouble(2));
			}
			return productBean;
			
		}
		catch(Exception pe)
		{
			System.err.println(pe.getMessage());
		}
		return null;
	}

	@Override
	public boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException, IOException {
		Connection con = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;
		ResultSet resultSet = null;
		ProductBean productBean = null;
		int productCode =0;
		int queryResult = 0;
		try
		{
			preparedStatement = con.prepareStatement(QueryMapper.INSERT_INTO_SALES_QUERY);
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setString(2, product.getProductCategory());
			preparedStatement.setString(3, product.getProductDescription());
			preparedStatement.setDouble(4, product.getProductPrice());
			preparedStatement.executeUpdate();
			queryResult++;
			
			preparedStatement2 = con.prepareStatement(QueryMapper.GET_PRODUCT_CODE_QUERY);
			preparedStatement2.setString(1, product.getProductDescription());
			resultSet = preparedStatement2.executeQuery();
			
			while(resultSet.next())
			{
				 productCode = resultSet.getInt(1);
			}
			
			preparedStatement1 = con.prepareStatement(QueryMapper.INSERT_LINECODE_QUERY);
			preparedStatement1.setInt(1,resultSet.getInt(1));
			preparedStatement1.setDouble(2, product.getQuantity());
			preparedStatement1.executeUpdate();
			queryResult++;
			
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
		
		
		return false;
	}

}
