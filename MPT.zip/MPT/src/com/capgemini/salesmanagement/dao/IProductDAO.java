package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;

public interface IProductDAO {
	
	ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, IOException;
	boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException, IOException;

}
