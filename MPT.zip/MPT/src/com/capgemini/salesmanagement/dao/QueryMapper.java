package com.capgemini.salesmanagement.dao;

public interface QueryMapper {
	
	String GET_PRODUCT_QUERY = "select * from product where product_code = ?";
	String UPDATE_SALES_QUERY = "update sales set line_total=?*quantity where product_code=?";
	String GET_REQUIRED_FIELDS = "select quantity,line_total from sales where product_code = ?";
	
	String INSERT_INTO_SALES_QUERY = "insert into product values(product_code_seq.nextval,?,?,?,?)";
	String GET_PRODUCT_CODE_QUERY = "select product_code from product where product_description = ?";
	String INSERT_LINECODE_QUERY = "insert into sales values(sales_id_seq1.nextval,?,?,sysdate,0)";

}
