package com.capgemini.salesmanagement.sevice;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;

public interface IProductService {
	
	ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, IOException;
	boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException, IOException;

}
