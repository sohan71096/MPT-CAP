package com.capgemini.salesmanagement.sevice;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IProductDAO;
import com.capgemini.salesmanagement.dao.ProductDAO;

import exception.ProductException;

public class ProductService implements IProductService {

	IProductDAO iProductDAO = null;
	
	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, IOException {
		iProductDAO = new ProductDAO();
		ProductBean productBean =  null;
		productBean = iProductDAO.getProductDetails(productCode);
		return productBean;
	}

	@Override
	public boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException, IOException {
		boolean ret;
		iProductDAO = new ProductDAO();
		ret = iProductDAO.insertSalesDetails(product);
		return ret;
	}
	
	public void validateProductDetails(ProductBean productBean) throws ProductException
	{
		List<String> errorsList = new ArrayList<>();
		
		if(!(isValidProductName(productBean.getProductName())))
		{
			errorsList.add(" product name must be minimum 4 characters ..");
		}
		
		if(!(isValidProductCategory(productBean.getProductCategory())))
		{
			errorsList.add(" product category must be Electronics or Toys or Stationary..");
		}
		
		if(!(isValidProductDescription(productBean.getProductDescription())))
		{
			errorsList.add(" description can be given or be left");
		}
		
		if(!(isValidProductPrice(productBean.getProductPrice())))
		{
			errorsList.add(" price must be number greater than 1000 ");
		}
		if(!errorsList.isEmpty())
		{
			throw new ProductException(errorsList+" ");
		}
	}
	
	public boolean isValidProductCode(int productCode)
	{
		return productCode>1000;
	}
	
	public boolean isValidQuantity(double quantity)
	{
		return quantity > 0;
	}
	
	public boolean isValidProductName(String productName)
	{
		Pattern namePattern = Pattern.compile("[A-Za-z]{4,}");
		Matcher nameMatcher = namePattern.matcher(productName);
		return nameMatcher.matches();
	}
	
	public boolean isValidProductCategory(String productCategory)
	{
		Pattern categoryPattern = Pattern.compile("[A-Za-z]{3,}");
		Matcher categoryMatcher = categoryPattern.matcher(productCategory);
		return categoryMatcher.matches();
	}
	
	public boolean isValidProductDescription(String productDescription)
	{
		Pattern descriptionPattern = Pattern.compile("[A-Za-z//sA-Za-z]{0,}");
		Matcher descriptionMatcher = descriptionPattern.matcher(productDescription);
		return descriptionMatcher.matches();
	}
	
	public boolean isValidProductPrice(double productPrice)
	{
		return productPrice>1000;
	}

}
