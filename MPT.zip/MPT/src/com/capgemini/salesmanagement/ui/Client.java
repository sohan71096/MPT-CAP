package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.sevice.IProductService;
import com.capgemini.salesmanagement.sevice.ProductService;

import exception.ProductException;

public class Client
{
	
	static IProductService iProductService = null;
	static ProductService productService = null;
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args) throws ProductException
	{
		
		while(true)
		{
			System.out.println("--*---*---*---*---*---");
			System.out.println("--*---*-Menu-*---*---*");
			System.out.println("--*---*---*---*---*---");
			System.out.println("    1 . view product details  ");
			System.out.println("    2 . insert product details");
			System.out.println("    3 . Exit    ");
			int option;
			System.out.println(" enter option from menu  ");
			option = in.nextInt();
			switch(option)
			{
				case 1:
						int productCode = 0;
						System.out.println(" enter product code to get details ");
						productCode = in.nextInt();
						ProductBean productBean = null;
						productService = new ProductService();
						iProductService = new ProductService();
						
						if(productService.isValidProductCode(productCode));
						{
							try
							{
							productBean = iProductService.getProductDetails(productCode);
							System.out.println(productBean);
							}
							catch(Exception pe)
							{
								System.err.println(pe.getMessage());
							}
							finally
							{
								productBean = null;
								productCode = 0;
								productService =null;
								iProductService = null;
							}
						}
					break;
				case 2:
						boolean ret;
						productBean = null;
						productBean = populateProduct();
						
						productService = new ProductService();
						iProductService = new ProductService();
						try
						{
						ret = iProductService.insertSalesDetails(productBean);
						System.out.println(ret);
						}
						catch(Exception e)
						{
							System.err.println(e.getMessage());
						}
						
					break;
				case 3:
					System.exit(0);
				default:
					System.out.println("please enter valid option from menu...");
					break;
			}
			
		}
		
	}
	static public ProductBean populateProduct() throws ProductException
	{
		productService = new ProductService();
		ProductBean productBean = new ProductBean();
		
		System.out.println(" enter details of product ");
		
		System.out.println(" enter product name ");
		productBean.setProductName(in.next());
		
		System.out.println("enter product Category ");
		productBean.setProductCategory(in.next());
		
		System.out.println(" enter product description ");
		productBean.setProductDescription(in.next());
		
		System.out.println(" enetr product price ");
		productBean.setProductPrice(in.nextDouble());
		
		System.out.println(" enter quantity of product ");
		productBean.setQuantity(in.nextDouble());
		
		try
		{
			productService.validateProductDetails(productBean);
			return productBean;
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
		return null;
	}

}
