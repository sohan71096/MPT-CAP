package com.capgemini.salesmanagement.bean;

public class ProductBean {
	
	private String productName;
	private String productCategory;
	private String productDescription;
	private double productPrice;
	private double quantity;
	private double lineTotal;
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(double lineTotal) {
		this.lineTotal = lineTotal;
	}
	
	
	@Override
	public String toString() {
		return "ProductBean [productName=" + productName + ", productCategory=" + productCategory
				+ ", productDescription=" + productDescription + ", productPrice=" + productPrice + ", quantity="
				+ quantity + ", lineTotal=" + lineTotal + "]";
	}
	

}
