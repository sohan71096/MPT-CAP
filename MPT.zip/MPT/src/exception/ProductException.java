package exception;

public class ProductException extends Exception{

	public ProductException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
